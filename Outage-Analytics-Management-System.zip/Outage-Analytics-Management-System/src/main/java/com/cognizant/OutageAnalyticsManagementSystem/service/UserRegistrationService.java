package com.cognizant.OutageAnalyticsManagementSystem.service;

import com.cognizant.OutageAnalyticsManagementSystem.model.User;
import com.cognizant.OutageAnalyticsManagementSystem.repository.UserRegistrationRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserRegistrationService {
    @Autowired
    private UserRegistrationRepo userRegistrationRepo;
    public void userRegistration(User user)
    {
        userRegistrationRepo.save(user);
    }
}
