package com.cognizant.OutageAnalyticsManagementSystem.model;

import org.hibernate.exception.DataException;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Tickets {
    @Id
    @GeneratedValue
    private Long ticket_id;
    private int contact;
    private int zip;
    private String issue;
    private String creation_time;
    @Column(columnDefinition = "varchar(200) default 'Ongoing' ")
    private String status= "Ongoing";

    public Long getTicket_id() {
        return ticket_id;
    }

    public void setTicket_id(Long ticket_id) {
        this.ticket_id = ticket_id;
    }

    public int getContact() {
        return contact;
    }

    public void setContact(int contact) {
        this.contact = contact;
    }

    public int getZip() {
        return zip;
    }

    public void setZip(int zip) {
        this.zip = zip;
    }

    public String getIssue() {
        return issue;
    }

    public void setIssue(String issue) {
        this.issue = issue;
    }

    public String  getCreation_time() {
        return creation_time;
    }

    public void setCreation_time(String  creation_time) {
        this.creation_time = creation_time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
