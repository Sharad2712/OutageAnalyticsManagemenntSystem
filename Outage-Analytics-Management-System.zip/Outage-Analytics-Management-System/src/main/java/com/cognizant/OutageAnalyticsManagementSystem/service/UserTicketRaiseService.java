package com.cognizant.OutageAnalyticsManagementSystem.service;

import com.cognizant.OutageAnalyticsManagementSystem.model.Tickets;
import com.cognizant.OutageAnalyticsManagementSystem.repository.TicketsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserTicketRaiseService {
    @Autowired
   private TicketsRepo ticketsRepo;

    public long ticketRaise(Tickets tickets)
    {
        ticketsRepo.save(tickets);
        return tickets.getTicket_id();

    }
}
