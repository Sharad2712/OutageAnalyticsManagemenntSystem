//package com.cognizant.OutageAnalyticsManagementSystem;
//
//import com.cognizant.OutageAnalyticsManagementSystem.model.User;
//import com.cognizant.OutageAnalyticsManagementSystem.repository.UserRegistrationRepo;
//import com.cognizant.OutageAnalyticsManagementSystem.service.UserRegistrationService;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//
//
//
//
//import java.util.ArrayList;
//import java.util.Optional;
//import java.util.stream.Collectors;
//
//
//
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertTrue;
//import static org.mockito.Mockito.when;
//
//
//
//
//@SpringBootTest
//class UserApplicationTests {
//
//
//
//    @Autowired
//    private UserRegistrationService userRegistrationService;
//    @MockBean
//    private UserRegistrationRepo userRepo;
//
//
//
//    //post
//    @Test
//    public void userRegistrationTest() {
//
//
//
//        User user = new User(1, "Sam", "samt007", "am00**@@", "Patharquary", "Assam", "India", 781171, "xyz@gmail.com", "Geep@xyz", "1234567890", "1996/12/23",1, null
//        );
//        when(userRepo.save(user)).thenReturn(user);
//        assertEquals(user, userService.addUser(user));
//    }
//
//
//
//    //get
//    @Test
//    public void findByIdTest() throws UserNotFoundException {
//        User user = new User(1, "Sharad", "shar007", "am00**@@", "Patharquary", "Assam", "India", 781171, "xyz@gmail.com", "Geep@xyz", "1234567890", "1996/12/23", 1, null  );
//        when(userRepo.findById(1)).thenReturn(Optional.of(user));
//        assertEquals(Optional.of(user), userService.findById(1));
//    }
//
//
//
//    //getAll
//    @Test
//    public void findAllTest() {
//        ArrayList<User> userList = new ArrayList<User>();
//        userList.add(new User(1, "Anuj", "anuj007", "am00**@@", "Patharquary", "Assam", "India", 781171, "xyz@gmail.com", "Geep@xyz", "1234567890", "1996/12/23",1,null));
//        userList.add(new User(1, "Sharad", "singh000", "ajkl**@@", "Patharquary", "Assam", "India", 781026, "xyz@hotmail.com", "tvkd@xyz", "0987654321", "1996/12/23",1,null));
//        when(userRepo.findAll()).thenReturn(userList.stream().collect(Collectors.toList()));
//        assertEquals(2, userService.findAll().size());
//    }
//
//
//
//    //update
//    @Test
//    public void updateUserTest() {
//        User user = new User(1, "Sharad", "ameet007", "am00**@@", "Patharquary", "Assam", "India", 781171, "xyz@gmail.com", "Geep@xyz", "1234567890", "1996/12/23",1,null);
//        when(userRepo.findById(1)).thenReturn(Optional.of(user));
//        user.setContactNumber("9678757581");
//        user.setZipCode(781026);
//        when(userRepo.save(user)).thenReturn(user);
//        assertTrue(userService.updateUser(user).equals(user));
//
//
//
//    }
//
//
//
//}