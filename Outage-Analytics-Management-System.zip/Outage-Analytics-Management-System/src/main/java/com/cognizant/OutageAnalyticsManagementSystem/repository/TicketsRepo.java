package com.cognizant.OutageAnalyticsManagementSystem.repository;

import com.cognizant.OutageAnalyticsManagementSystem.model.Tickets;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
@Component
@Repository
public interface TicketsRepo extends JpaRepository<Tickets, Long> {

}
