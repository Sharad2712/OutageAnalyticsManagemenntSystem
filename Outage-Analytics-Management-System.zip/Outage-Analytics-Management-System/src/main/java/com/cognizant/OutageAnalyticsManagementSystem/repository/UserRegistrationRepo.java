package com.cognizant.OutageAnalyticsManagementSystem.repository;

import com.cognizant.OutageAnalyticsManagementSystem.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRegistrationRepo extends JpaRepository<User, Integer> {
}
