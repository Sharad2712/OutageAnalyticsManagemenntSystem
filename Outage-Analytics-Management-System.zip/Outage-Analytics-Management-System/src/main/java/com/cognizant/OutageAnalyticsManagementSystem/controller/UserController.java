package com.cognizant.OutageAnalyticsManagementSystem.controller;

import com.cognizant.OutageAnalyticsManagementSystem.model.Tickets;
import com.cognizant.OutageAnalyticsManagementSystem.model.User;
import com.cognizant.OutageAnalyticsManagementSystem.service.UserRegistrationService;
import com.cognizant.OutageAnalyticsManagementSystem.service.UserTicketRaiseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/login")
public class UserController {
	@Autowired
	private UserTicketRaiseService userTicketRaiseService;
	@PostMapping("/user/dashboard/raiseTicket")
	public ResponseEntity<String> raiseTicket(@RequestBody Tickets tickets)
	{
		long l=userTicketRaiseService.ticketRaise(tickets);
		String s="Ticket Raised Sucessfully... Your ticket_id is : "+Long.toString(l);
		return
				new ResponseEntity<String>(s, HttpStatus.OK);
				//: new ResponseEntity<String>("ACCOUNT NOT APPROVED YET< PLS WAIT",HttpStatus.FORBIDDEN);


	}
    @Autowired
    private UserRegistrationService userRegistrationService;
	@PostMapping("/newUser/registration")
    public ResponseEntity<String> registerUser(@RequestBody User user)
    {
        userRegistrationService.userRegistration(user);
        return new ResponseEntity<String>("Sucessfully Registered", HttpStatus.OK);
    }
    @GetMapping("/test")
	public String test()
	{
		return "TEst successfull";
	}
}
