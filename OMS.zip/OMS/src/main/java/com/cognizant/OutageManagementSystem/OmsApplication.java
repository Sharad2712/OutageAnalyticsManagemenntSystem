package com.cognizant.OutageManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.AutoConfigurationPackage;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
@EnableDiscoveryClient
@EnableAutoConfiguration
@SpringBootApplication
@EntityScan(value = "com.cognizant.OutageAnalyticsManagementSystem.model")
@EnableJpaRepositories(value = "com.cognizant.OutageAnalyticsManagementSystem.repository")
//@ComponentScan(basePackages = {"com.cognizant.OutageAnalyticsManagementSystem"})
public class OmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(OmsApplication.class, args);
	}

}
