package com.cognizant.OutageManagementSystem.com.cognizant.OutageManagementSystem.Service;

import com.cognizant.OutageAnalyticsManagementSystem.model.User;
import com.cognizant.OutageAnalyticsManagementSystem.repository.UserRegistrationRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UpdateCustomer {
    @Autowired
    private UserRegistrationRepo userRegistrationRepo;
    public String customerUpdate(User U)
    {

      User U2= userRegistrationRepo.getOne(U.getUser_id());
      U2.setEmail(U.getEmail());
      U2.setZip(U.getZip());
      U2.setRole(U.getRole());
      userRegistrationRepo.save(U2);
        return "User with user name :"+U2.getUsername() +" is sucessfully updated."+ U2.getUsername()+" now has USER ACCESS";


    }
}
