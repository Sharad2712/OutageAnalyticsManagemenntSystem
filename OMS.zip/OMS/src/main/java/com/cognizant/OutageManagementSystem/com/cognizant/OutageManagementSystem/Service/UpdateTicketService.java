package com.cognizant.OutageManagementSystem.com.cognizant.OutageManagementSystem.Service;

import com.cognizant.OutageAnalyticsManagementSystem.model.Tickets;
import com.cognizant.OutageAnalyticsManagementSystem.repository.TicketsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UpdateTicketService {

    @Autowired
    private TicketsRepo ticketsRepo;
    public String updateTicketStatus(Long l, String s)
    {
       Tickets t= ticketsRepo.getOne(l);

       t.setStatus(s);
       ticketsRepo.save(t);
       return t.getStatus();

    }
}