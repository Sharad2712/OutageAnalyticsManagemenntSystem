package com.cognizant.OutageManagementSystem.com.cognizant.OutageManagementSystem.Controller;

import com.cognizant.OutageAnalyticsManagementSystem.model.User;
import com.cognizant.OutageManagementSystem.com.cognizant.OutageManagementSystem.Service.UpdateCustomer;
import com.cognizant.OutageManagementSystem.com.cognizant.OutageManagementSystem.Service.UpdateTicketService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping(value = "/admin")
public class AdminController {

    @Autowired
    private UpdateTicketService updateTicketService;
    @Autowired
    private UpdateCustomer updateCustomer;


    @PostMapping("/updateTicket")
    public String updateTicketStatus( @RequestParam  Long ticket_id, @RequestParam String status)
    {
        String StatusUpdate="Ticket status updated sucessfull...Status updated to : "+ updateTicketService.updateTicketStatus(ticket_id,status);
        return StatusUpdate;
    }
    @PostMapping("/updateCustomer")
    public String updateCustomer(@RequestBody User user)
    {
        return  updateCustomer.customerUpdate(user);
    }
}